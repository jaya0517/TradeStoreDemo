package com.dbInterview.TradeDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TradeDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
